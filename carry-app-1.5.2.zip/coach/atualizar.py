"""Atualizacao automatica do Carry.

O site publica versao.json (versao, endereco do pacote .zip, sha256 e notas). O app confere fora de partida, mostra
"Atualizacao disponivel" e, quando a pessoa clica, baixa o pacote, confere o sha256, guarda uma copia da versao atual
e troca SO os arquivos do app (coach/*.py, coach/static, o lancador e o icone). Dados, chaves e configuracoes nunca
sao tocados. Depois o vigia de arquivos do app reinicia sozinho (e nunca no meio de uma partida).
"""
import hashlib
import io
import json
import os
import shutil
import threading
import time
import urllib.request
import zipfile

URLS = [os.environ["CARRY_UPDATE_URL"]] if os.environ.get("CARRY_UPDATE_URL") else [
    "https://carry-coach.app/versao.json",
    "https://enuria-finance.github.io/carry/versao.json",  # endereco antigo, so como reserva
]
URL = URLS[0]
RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PERMITIDOS = ("coach/", "LoL Coach.pyw", "carry.ico", "VERSAO.txt", "NOVIDADES.json", "Carry.exe")
STATE = {"checked": 0, "info": None, "err": None, "busy": False, "msg": None, "ready": None, "later_until": 0.0}
_LOCK = threading.Lock()


def atual():
    try:
        with open(os.path.join(RAIZ, "VERSAO.txt"), encoding="utf-8") as fh:
            return fh.read().strip() or "0.0.0"
    except OSError:
        return "0.0.0"


def _v(s):
    out = []
    for p in str(s or "0").split("."):
        try:
            out.append(int("".join(ch for ch in p if ch.isdigit()) or 0))
        except ValueError:
            out.append(0)
    return tuple(out + [0] * (3 - len(out)))


def checar(force=False):
    """Busca versao.json (no maximo 1x por hora). Devolve o dict da versao nova ou None."""
    with _LOCK:
        if not force and time.time() - STATE["checked"] < 3600:
            return STATE["info"]
        STATE["checked"] = time.time()
    try:
        info, ultimo = None, None
        for u in URLS:
            try:
                req = urllib.request.Request(u + f"?t={int(time.time())}", headers={"User-Agent": "Carry-app"})
                with urllib.request.urlopen(req, timeout=8) as r:
                    info = json.loads(r.read().decode("utf-8"))
                break
            except Exception as ex:
                ultimo = ex
        if info is None:
            raise ultimo or RuntimeError("sem resposta")
        nova = info if _v(info.get("versao")) > _v(atual()) and info.get("zip") and info.get("sha256") else None
        STATE.update(info=nova, err=None)
        if nova and STATE.get("ready") != nova.get("versao"):
            threading.Thread(target=baixar, args=(nova,), daemon=True).start()
        return nova
    except Exception as ex:
        STATE.update(err=str(ex)[:120])
        return STATE["info"]


def _zip_path(v):
    return os.path.join(RAIZ, "cache", f"update_{v}.zip")


def baixar(info):
    """Baixa e confere o pacote em segundo plano, como o launcher do ROTK: quando a pessoa ve o aviso, a atualizacao
    ja esta pronta e instalar leva poucos segundos."""
    try:
        fp = _zip_path(info["versao"])
        if os.path.exists(fp):
            with open(fp, "rb") as fh:
                if hashlib.sha256(fh.read()).hexdigest().lower() == str(info["sha256"]).lower():
                    STATE["ready"] = info["versao"]
                    return True
        req = urllib.request.Request(info["zip"], headers={"User-Agent": "Carry-app"})
        with urllib.request.urlopen(req, timeout=180) as r:
            data = r.read()
        if hashlib.sha256(data).hexdigest().lower() != str(info["sha256"]).lower():
            return False
        os.makedirs(os.path.dirname(fp), exist_ok=True)
        with open(fp + ".novo", "wb") as fh:
            fh.write(data)
        os.replace(fp + ".novo", fp)
        STATE["ready"] = info["versao"]
        return True
    except Exception as ex:
        STATE["err"] = str(ex)[:120]
        return False


def depois(horas=4):
    """Botao DEPOIS: o aviso some por algumas horas (volta na proxima vez que o Carry abrir)."""
    STATE["later_until"] = time.time() + horas * 3600


def checar_em_fundo():
    threading.Thread(target=checar, daemon=True).start()


def _seguro(nome):
    n = nome.replace("\\", "/")
    if n.startswith("/") or ".." in n.split("/"):
        return False
    return n.startswith(PERMITIDOS[0]) or n in PERMITIDOS[1:]


def aplicar(info=None, log=print):
    """Baixa, confere e instala. Devolve (ok, mensagem)."""
    info = info or STATE.get("info") or checar(force=True)
    if not info:
        return False, "Você já está na versão mais nova."
    with _LOCK:
        if STATE["busy"]:
            return False, "A atualização já está em andamento."
        STATE["busy"] = True
    try:
        fp = _zip_path(info["versao"])
        if STATE.get("ready") == info["versao"] and os.path.exists(fp):
            with open(fp, "rb") as fh:          # ja baixado em segundo plano
                data = fh.read()
        else:
            log(f"Baixando a versão {info['versao']}…")
            req = urllib.request.Request(info["zip"], headers={"User-Agent": "Carry-app"})
            with urllib.request.urlopen(req, timeout=120) as r:
                data = r.read()
        if hashlib.sha256(data).hexdigest().lower() != str(info["sha256"]).lower():
            return False, "O arquivo baixado não confere (sha256). Nada foi trocado: tente de novo mais tarde."
        z = zipfile.ZipFile(io.BytesIO(data))
        nomes = [n for n in z.namelist() if not n.endswith("/")]
        if not nomes or not all(_seguro(n) for n in nomes):
            return False, "O pacote tem arquivos fora do esperado. Nada foi trocado."
        bk = os.path.join(RAIZ, "cache", f"backup_{atual()}")
        shutil.rmtree(bk, ignore_errors=True)
        os.makedirs(bk, exist_ok=True)
        if os.path.isdir(os.path.join(RAIZ, "coach")):
            shutil.copytree(os.path.join(RAIZ, "coach"), os.path.join(bk, "coach"),
                            ignore=shutil.ignore_patterns("__pycache__"))
        for f in PERMITIDOS[1:]:
            if os.path.exists(os.path.join(RAIZ, f)):
                shutil.copy2(os.path.join(RAIZ, f), bk)
        log("Instalando…")
        # o lancador e o icone primeiro; os .py do app por ultimo (o vigia reinicia quando eles mudam)
        for n in sorted(nomes, key=lambda x: (x.startswith("coach/") and x.endswith(".py"), x)):
            dest = os.path.join(RAIZ, *n.split("/"))
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            tmp = dest + ".novo"
            with z.open(n) as src, open(tmp, "wb") as out:
                shutil.copyfileobj(src, out)
            os.replace(tmp, dest)
        STATE.update(info=None, msg=f"Atualizado para a versão {info['versao']}. O app reinicia sozinho em alguns segundos.")
        return True, STATE["msg"]
    except Exception as ex:
        return False, f"Não deu para atualizar agora ({str(ex)[:100]}). Nada foi perdido."
    finally:
        STATE["busy"] = False


DL_SVG = ("<svg viewBox='0 0 24 24' width='26' height='26' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' "
          "stroke-linejoin='round' aria-hidden='true'><path d='M12 4v11'/><path d='m7 10 5 5 5-5'/><path d='M5 20h14'/></svg>")


def modal_html(e):
    """Janela de atualizacao no estilo do launcher do ROTK: versao instalada -> disponivel, REINICIAR PARA INSTALAR e DEPOIS.
    Nunca aparece com partida rolando, nem depois de DEPOIS (volta em 4 horas ou na proxima abertura)."""
    info = STATE.get("info")
    if not info or time.time() < STATE.get("later_until", 0):
        return ""
    try:
        from . import jobs
        if jobs.in_game():
            return ""
    except Exception:
        pass
    pronta = STATE.get("ready") == info.get("versao")
    notas = "".join(f"<li>{e(n)}</li>" for n in (info.get("notas") or [])[:6])
    return (
        "<div class='updm' id='updm' role='dialog' aria-modal='true' aria-labelledby='updm-t'><div class='updm-p'>"
        "<form method='post' action='/atualizar/depois' class='updm-x-f'><button class='updm-x' aria-label='Fechar' title='Depois'>&#x2715;</button></form>"
        f"<div class='updm-ic'>{DL_SVG}</div><p class='updm-k'>CARRY</p>"
        f"<h2 id='updm-t'>{'SUA ATUALIZAÇÃO ESTÁ PRONTA' if pronta else 'ATUALIZAÇÃO DISPONÍVEL'}</h2>"
        f"<p class='updm-s'>{'Reinicie o Carry para instalar a atualização. Leva poucos segundos e nada dos seus dados muda.' if pronta else 'O Carry está baixando a versão nova. Você já pode instalar: ele baixa e reinicia sozinho.'}</p>"
        f"<div class='updm-v'><div><small>INSTALADA</small><b>v{e(atual())}</b></div><span aria-hidden='true'>&rarr;</span>"
        f"<div class='r'><small>DISPONÍVEL</small><b>v{e(info.get('versao'))}</b></div></div>"
        + (f"<details class='updm-n'><summary>O que mudou</summary><ul>{notas}</ul></details>" if notas else "")
        + "<div class='updm-b'><form method='post' action='/atualizar'><button class='updm-go'>" + DL_SVG.replace("26", "16")
        + " REINICIAR PARA INSTALAR</button></form>"
        "<form method='post' action='/atualizar/depois'><button class='updm-later'>DEPOIS</button></form></div></div></div>"
        "<style>.updm{position:fixed;inset:0;z-index:9999;background:rgba(0,0,0,.72);display:flex;align-items:center;justify-content:center;"
        "backdrop-filter:blur(2px)}.updm-p{position:relative;width:min(602px,92vw);background:#0E0E0E;border:1px solid #2A2A2A;"
        "border-top:4px solid #E10600;padding:36px 36px 34px;color:#F4F4F4;font-family:'BL','Segoe UI',sans-serif;box-shadow:0 30px 80px rgba(0,0,0,.6)}"
        ".updm-x-f{position:absolute;top:18px;right:18px;margin:0}.updm-x{background:none;border:0;color:#BDBDBD;font-size:18px;cursor:pointer}"
        ".updm-x:hover{color:#fff}.updm-ic{width:58px;height:58px;display:flex;align-items:center;justify-content:center;background:#3A0B0B;color:#FF3B30}"
        ".updm-k{margin:22px 0 4px;font:700 12px/1 'CP','Bahnschrift',monospace;letter-spacing:.18em;color:#A8A8A8}"
        ".updm-p h2{margin:0 0 14px;font:800 34px/1.05 'BC','Bahnschrift','Arial Narrow',sans-serif;letter-spacing:.01em;color:#fff;text-transform:uppercase}"
        ".updm-s{margin:0 0 22px;color:#D8D8D8;font-size:15px}.updm-v{display:flex;align-items:center;justify-content:space-between;"
        "border:1px solid #333;background:#161616;padding:22px 24px;margin-bottom:22px}.updm-v small{display:block;font:600 11px 'CP',monospace;"
        "letter-spacing:.14em;color:#9A9A9A;margin-bottom:6px}.updm-v b{font:800 24px 'BC','Arial Narrow',sans-serif;color:#fff}.updm-v .r{text-align:right}"
        ".updm-v span{color:#FF3B30;font-size:22px}.updm-n{margin:-6px 0 18px;color:#BDBDBD;font-size:13px}.updm-n summary{cursor:pointer}"
        ".updm-b{display:grid;grid-template-columns:1fr 1fr;gap:12px}.updm-b form{margin:0}.updm-b button{width:100%;height:56px;cursor:pointer;"
        "font:700 14px 'CP','Bahnschrift',monospace;letter-spacing:.06em;text-transform:uppercase;display:flex;align-items:center;justify-content:center;gap:8px}"
        ".updm-go{background:#E10600;border:0;color:#fff}.updm-go:hover{background:#FF1A0D}.updm-later{background:transparent;border:1px solid #444;color:#EDEDED}"
        ".updm-later:hover{border-color:#777}</style>")


def banner_html(e):
    """Antes: faixa no topo. Agora a atualizacao aparece na janela do estilo ROTK (modal_html)."""
    return ""


def _banner_antigo(e):
    info = STATE.get("info")
    if not info:
        return ""
    notas = "".join(f"<li>{e(n)}</li>" for n in (info.get("notas") or [])[:5])
    return ("<div class='updbar' style='display:flex;gap:12px;align-items:center;flex-wrap:wrap;border:1px solid rgba(233,196,106,.45);"
            "background:rgba(233,196,106,.08);border-radius:12px;padding:10px 14px;margin:0 0 14px'>"
            f"<b>Atualização disponível: versão {e(info.get('versao'))}</b>"
            + (f"<details style='flex:1'><summary class='n' style='cursor:pointer'>O que mudou</summary><ul>{notas}</ul></details>" if notas else "<span style='flex:1'></span>")
            + "<form method='post' action='/atualizar'><button class='btn gold' style='width:auto'>Atualizar agora</button></form></div>")


VISTA = os.path.join(RAIZ, "cache", "novidades_vista.txt")


def novidades_html(e):
    """Uma vez depois de cada versao nova: o que mudou (de NOVIDADES.json, que vem no pacote)."""
    v = atual()
    try:
        if open(VISTA).read().strip() == v:
            return ""
    except OSError:
        pass
    try:
        with open(os.path.join(RAIZ, "NOVIDADES.json"), encoding="utf-8") as fh:
            d = json.load(fh)
    except Exception:
        return ""
    if str(d.get("versao")) != v or not d.get("notas"):
        return ""
    itens = "".join(f"<li>{e(n)}</li>" for n in d["notas"][:12])
    return ("<div class='card verdict' style='margin-bottom:14px'><b class='gl'>Novidades da versão " + e(v) + "</b>"
            f"<ul style='margin:8px 0'>{itens}</ul><form method='post' action='/novidades/ok'><button class='btn' style='width:auto'>Entendi</button></form></div>")


def novidades_ok():
    try:
        os.makedirs(os.path.dirname(VISTA), exist_ok=True)
        with open(VISTA, "w") as fh:
            fh.write(atual())
    except OSError:
        pass
