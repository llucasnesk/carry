"""Banco SQLite local. Guarda o que o app precisa para analisar.

Para as suas partidas guarda tambem o JSON bruto comprimido (tabela raw), assim
da para reprocessar offline quando o app aprender a ler mais coisas.
"""
import json
import os
import sqlite3
import time
import zlib

SCHEMA = """
CREATE TABLE IF NOT EXISTS matches (
    match_id TEXT PRIMARY KEY,
    queue_id INTEGER,
    patch TEXT,
    started_ms INTEGER,
    duration_s INTEGER,
    has_timeline INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS participants (
    match_id TEXT,
    participant_id INTEGER,
    puuid TEXT,
    team_id INTEGER,
    champion TEXT,
    position TEXT,
    win INTEGER,
    kills INTEGER, deaths INTEGER, assists INTEGER,
    cs INTEGER,
    gold INTEGER,
    vision_score INTEGER,
    PRIMARY KEY (match_id, participant_id)
);
-- Foto por minuto de cada jogador (CS, ouro, nivel, posicao)
CREATE TABLE IF NOT EXISTS frames (
    match_id TEXT,
    participant_id INTEGER,
    minute INTEGER,
    cs INTEGER, gold INTEGER, level INTEGER, xp INTEGER,
    x INTEGER, y INTEGER,
    PRIMARY KEY (match_id, participant_id, minute)
);
-- Mortes com minuto e posicao
CREATE TABLE IF NOT EXISTS deaths (
    match_id TEXT,
    t_ms INTEGER,
    victim_id INTEGER,
    killer_id INTEGER,
    x INTEGER, y INTEGER
);
CREATE TABLE IF NOT EXISTS wards (
    match_id TEXT,
    t_ms INTEGER,
    participant_id INTEGER,
    ward_type TEXT
);
CREATE INDEX IF NOT EXISTS ix_part_puuid ON participants(puuid);
CREATE INDEX IF NOT EXISTS ix_part_champ ON participants(champion);

-- Outros eventos da timeline (objetivos, torres, itens, skills)
CREATE TABLE IF NOT EXISTS events (
    match_id TEXT, t_ms INTEGER, type TEXT,
    pid INTEGER, team_id INTEGER, x INTEGER, y INTEGER, data TEXT
);
CREATE INDEX IF NOT EXISTS ix_events_match ON events(match_id, type);
-- Itens finais, runas, feiticos e abates do time (JSON em texto)
CREATE TABLE IF NOT EXISTS participant_extra (
    match_id TEXT, participant_id INTEGER,
    items TEXT, perks TEXT, spells TEXT, team_kills INTEGER,
    PRIMARY KEY (match_id, participant_id)
);
CREATE TABLE IF NOT EXISTS raw (
    match_id TEXT, kind TEXT, blob BLOB,
    PRIMARY KEY (match_id, kind)
);
-- De onde veio cada partida: 'me' (sua) ou 'top' (amostra dos melhores)
CREATE TABLE IF NOT EXISTS match_source (match_id TEXT PRIMARY KEY, source TEXT);
CREATE TABLE IF NOT EXISTS seen_matches (match_id TEXT PRIMARY KEY);
CREATE TABLE IF NOT EXISTS top_players (
    puuid TEXT PRIMARY KEY, tier TEXT, lp INTEGER, fetched_ms INTEGER
);
-- Respostas da revisao guiada
CREATE TABLE IF NOT EXISTS review_answers (
    match_id TEXT, t_ms INTEGER, kind TEXT,
    thought TEXT, cause TEXT, knew_jungler TEXT, updated_ms INTEGER,
    PRIMARY KEY (match_id, t_ms, kind)
);
CREATE TABLE IF NOT EXISTS match_notes (
    match_id TEXT PRIMARY KEY, do_different TEXT, feeling TEXT, updated_ms INTEGER
);
-- Um foco por jogo: meta unica que o app cobra no proximo jogo sincronizado
CREATE TABLE IF NOT EXISTS focus (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    created_ms INTEGER, text TEXT, metric TEXT, op TEXT, target REAL,
    match_id TEXT, value REAL, met INTEGER
);
-- indices que faltavam: sem eles cada pagina varria as tabelas inteiras (milhoes de linhas com a base dos melhores)
CREATE INDEX IF NOT EXISTS ix_deaths_match ON deaths(match_id, victim_id, t_ms);
CREATE INDEX IF NOT EXISTS ix_wards_match ON wards(match_id, participant_id);
CREATE INDEX IF NOT EXISTS ix_part_champ_pos ON participants(champion, position);
CREATE INDEX IF NOT EXISTS ix_source ON match_source(source);
CREATE INDEX IF NOT EXISTS ix_matches_started ON matches(started_ms);
"""

# Versao dos dados guardados por partida. Subiu para 3 quando entraram eventos,
# runas e itens: partidas antigas sao baixadas de novo uma vez.
DATA_VERSION = 3


_READY = set()


def connect(path):
    """Abre o banco. A preparacao (tabelas e migracao) roda uma vez por arquivo; antes rodava a cada pagina e
    brigava com a busca de partidas em segundo plano ('database is locked')."""
    con = sqlite3.connect(path, timeout=20)
    con.row_factory = sqlite3.Row
    key = None
    if isinstance(path, str) and path != ":memory:" and not path.startswith("file:"):
        try:
            st = os.stat(path)
            key = (os.path.abspath(path), st.st_ino, st.st_dev)
        except OSError:
            key = None
    if key is not None and key in _READY:
        return con
    try:                # WAL: quem le (overlay, paginas) nao espera quem grava (busca de partidas em segundo plano)
        con.execute("PRAGMA journal_mode=WAL")
    except sqlite3.OperationalError:
        pass
    try:
        con.executescript(SCHEMA)
        cols = {r[1] for r in con.execute("PRAGMA table_info(matches)")}
        if "v" not in cols:
            con.execute("ALTER TABLE matches ADD COLUMN v INTEGER DEFAULT 1")
        # Banco da V0 so tinha partidas suas: marca a origem para o app usa-las ja.
        con.execute("INSERT OR IGNORE INTO match_source SELECT match_id, 'me' FROM matches WHERE COALESCE(v,1) < 3")
        con.commit()
        try:
            if not con.execute("SELECT 1 FROM sqlite_master WHERE name='sqlite_stat1'").fetchone():
                con.execute("ANALYZE")        # uma vez: o SQLite passa a escolher os indices certos
                con.commit()
        except sqlite3.OperationalError:
            pass
        if key is not None:
            _READY.add(key)
    except sqlite3.OperationalError:
        pass            # banco ocupado agora: tenta preparar na proxima abertura, a leitura segue
    return con


def known_match_ids(con, min_version=DATA_VERSION):
    """Partidas ja salvas na versao atual dos dados."""
    return {r[0] for r in con.execute(
        "SELECT match_id FROM matches WHERE COALESCE(v,1) >= ?", (min_version,))}


def _pack(obj):
    return zlib.compress(json.dumps(obj, separators=(",", ":")).encode("utf-8"), 6)


def load_raw(con, match_id, kind):
    row = con.execute("SELECT blob FROM raw WHERE match_id=? AND kind=?",
                      (match_id, kind)).fetchone()
    return json.loads(zlib.decompress(row[0]).decode("utf-8")) if row else None


REMAKE_MAX_S = 300          # o app inteiro ignora partida com duration_s < 300


MITIGADA_MAX_S = 900          # rendicao antes dos 15 min so acontece quando alguem do time saiu: a Riot "mitiga" a derrota (sem perda de PDL)


def mitigated(match_json, puuid):
    """Derrota mitigada: alguem do seu time abandonou, o time se rendeu antes dos 15 min e voce perdeu.
    A Riot nao marca isso como remake (gameEndedInEarlySurrender fica falso): o sinal e rendicao + menos de 15 min."""
    try:
        info = match_json.get("info") or {}
        ps = info.get("participants") or []
        if not puuid or (info.get("gameDuration") or 0) >= MITIGADA_MAX_S:
            return False
        me = next((p for p in ps if p.get("puuid") == puuid), None)
        if not me or me.get("win"):
            return False
        return any(p.get("gameEndedInSurrender") for p in ps)
    except AttributeError:
        return False


def my_puuid(con):
    """Seu puuid: o que aparece em quase todas as partidas baixadas por voce (source 'me')."""
    try:
        row = con.execute("SELECT puuid, COUNT(*) c FROM participants WHERE match_id IN "
                          "(SELECT match_id FROM match_source WHERE source='me') GROUP BY puuid ORDER BY c DESC LIMIT 1").fetchone()
        return row[0] if row else None
    except sqlite3.OperationalError:
        return None


def is_remake(match_json, puuid=None):
    """Remake (votacao /remake): a Riot marca gameEndedInEarlySurrender. Antes o app so olhava a duracao, e remake com
    mais de 5 min (carregamento demorado, votacao no limite) aparecia como derrota. Derrota mitigada (abandono + rendicao
    antes dos 15 min) tambem nao conta, quando se sabe quem e voce."""
    try:
        ps = (match_json.get("info") or {}).get("participants") or []
        if any(p.get("gameEndedInEarlySurrender") for p in ps):
            return True
    except AttributeError:
        return False
    return mitigated(match_json, puuid)


def fix_remakes(con):
    """Uma vez por banco: partidas suas ja salvas que foram remake ou derrota mitigada passam a ser ignoradas."""
    try:
        con.execute("CREATE TABLE IF NOT EXISTS app_flags (k TEXT PRIMARY KEY, v TEXT)")
        if con.execute("SELECT 1 FROM app_flags WHERE k='remakes_v2'").fetchone():
            return 0
        me = my_puuid(con)
        n = 0
        for (mid,) in con.execute("SELECT match_id FROM matches WHERE COALESCE(duration_s,0) BETWEEN ? AND 1200",
                                  (REMAKE_MAX_S,)).fetchall():
            try:
                mj = load_raw(con, mid, "match")
            except Exception:
                mj = None
            if mj and is_remake(mj, me):
                con.execute("UPDATE matches SET duration_s=? WHERE match_id=?", (REMAKE_MAX_S - 1, mid))
                n += 1
        con.execute("INSERT OR REPLACE INTO app_flags VALUES ('remakes_v2', ?)", (str(n),))
        con.commit()
        return n
    except sqlite3.OperationalError:
        return 0


def save_match(con, match_json, timeline_json=None, source="me", me=None):
    info = match_json["info"]
    mid = match_json["metadata"]["matchId"]
    patch = ".".join(info.get("gameVersion", "").split(".")[:2])
    dur = info.get("gameDuration")
    if (dur or 0) >= REMAKE_MAX_S and is_remake(match_json, (me or my_puuid(con)) if source == "me" else None):
        dur = REMAKE_MAX_S - 1          # remake: o app inteiro ignora partida com menos de 5 min (vale para tudo de uma vez)
    con.execute(
        "INSERT OR REPLACE INTO matches VALUES (?,?,?,?,?,?,?)",
        (mid, info.get("queueId"), patch, info.get("gameStartTimestamp"),
         dur, 1 if timeline_json else 0, DATA_VERSION),
    )
    con.execute("INSERT OR REPLACE INTO match_source VALUES (?,?)", (mid, source))
    team_kills = {}
    for p in info["participants"]:
        team_kills[p["teamId"]] = team_kills.get(p["teamId"], 0) + p.get("kills", 0)
    for p in info["participants"]:
        cs = p.get("totalMinionsKilled", 0) + p.get("neutralMinionsKilled", 0)
        con.execute(
            "INSERT OR REPLACE INTO participants VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (mid, p["participantId"], p["puuid"], p["teamId"], p["championName"],
             p.get("teamPosition", ""), 1 if p.get("win") else 0,
             p.get("kills", 0), p.get("deaths", 0), p.get("assists", 0), cs,
             p.get("goldEarned", 0), p.get("visionScore", 0)),
        )
        items = [p.get(f"item{i}", 0) for i in range(7)]
        con.execute(
            "INSERT OR REPLACE INTO participant_extra VALUES (?,?,?,?,?,?)",
            (mid, p["participantId"], json.dumps(items),
             json.dumps(p.get("perks") or {}),
             json.dumps([p.get("summoner1Id"), p.get("summoner2Id")]),
             team_kills.get(p["teamId"], 0)),
        )
    if timeline_json:
        _save_timeline(con, mid, timeline_json)
    if source == "me":
        con.execute("INSERT OR REPLACE INTO raw VALUES (?,?,?)", (mid, "match", _pack(match_json)))
        if timeline_json:
            con.execute("INSERT OR REPLACE INTO raw VALUES (?,?,?)", (mid, "timeline", _pack(timeline_json)))
    con.commit()


_GENERIC_EVENTS = ("ELITE_MONSTER_KILL", "BUILDING_KILL", "TURRET_PLATE_DESTROYED",
                   "ITEM_PURCHASED", "ITEM_SOLD", "ITEM_UNDO", "SKILL_LEVEL_UP",
                   "GAME_END")


def _save_timeline(con, mid, tl):
    # Remove dados antigos desta partida para nao duplicar ao reprocessar.
    for table in ("frames", "deaths", "wards", "events"):
        con.execute(f"DELETE FROM {table} WHERE match_id=?", (mid,))
    for frame in tl["info"]["frames"]:
        minute = frame["timestamp"] // 60000
        for pid, pf in frame["participantFrames"].items():
            pos = pf.get("position") or {}
            con.execute(
                "INSERT OR REPLACE INTO frames VALUES (?,?,?,?,?,?,?,?,?)",
                (mid, int(pid), minute,
                 pf.get("minionsKilled", 0) + pf.get("jungleMinionsKilled", 0),
                 pf.get("totalGold", 0), pf.get("level", 0), pf.get("xp", 0),
                 pos.get("x"), pos.get("y")),
            )
        for ev in frame.get("events", []):
            t = ev.get("type")
            if t == "CHAMPION_KILL":
                pos = ev.get("position") or {}
                con.execute(
                    "INSERT INTO deaths VALUES (?,?,?,?,?,?)",
                    (mid, ev["timestamp"], ev.get("victimId"), ev.get("killerId"),
                     pos.get("x"), pos.get("y")),
                )
                con.execute(
                    "INSERT INTO events VALUES (?,?,?,?,?,?,?,?)",
                    (mid, ev["timestamp"], t, ev.get("victimId"), None,
                     pos.get("x"), pos.get("y"),
                     json.dumps({"killer": ev.get("killerId"),
                                 "assists": ev.get("assistingParticipantIds", [])})),
                )
            elif t == "WARD_PLACED":
                con.execute(
                    "INSERT INTO wards VALUES (?,?,?,?)",
                    (mid, ev["timestamp"], ev.get("creatorId"), ev.get("wardType")),
                )
            elif t in _GENERIC_EVENTS:
                pos = ev.get("position") or {}
                pid = ev.get("participantId", ev.get("killerId"))
                team = ev.get("killerTeamId") if t == "ELITE_MONSTER_KILL" else ev.get("teamId")
                con.execute(
                    "INSERT INTO events VALUES (?,?,?,?,?,?,?,?)",
                    (mid, ev["timestamp"], t, pid, team, pos.get("x"), pos.get("y"),
                     json.dumps({k: v for k, v in ev.items()
                                 if k not in ("timestamp", "type", "position")})),
                )


def now_ms():
    return int(time.time() * 1000)
