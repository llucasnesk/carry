"""PDL de cada partida, igual ao League of Graphs: o app olha o elo no cliente antes e depois de CADA ranqueada.

Antes o PDL real dependia de fotos do elo tiradas pelo overlay (a cada 30 s, so com ele aberto). Quando a foto do
"depois" nao batia, a partida caia no estimado (~+21 / ~-19 fixos) e os numeros ficavam bem diferentes do real.

Agora um vigia roda junto do app (sem depender do overlay):
- fora de partida, guarda o elo a cada 20 s (rank_history, como antes);
- quando a ranqueada solo comeca, guarda o elo de antes com o id da partida;
- quando ela acaba, espera o cliente atualizar (vitorias + derrotas mudam) e grava o PDL exato em lp_game.
  Tambem tenta o aviso de PDL do proprio cliente (/lol-ranked/v1/current-lp-change-notification).
- remake: o placar nao muda; a partida fica marcada como remake (0 PDL), nunca como derrota.
"""
import threading
import time

from . import ranks

POLL_S = 10
WAIT_AFTER_S = 360          # depois da partida, espera ate 6 min o cliente atualizar o PDL

_STARTED = {"t": None}


def ensure_table(con):
    con.execute("""CREATE TABLE IF NOT EXISTS lp_game (
        match_id TEXT PRIMARY KEY, delta INTEGER, v_before INTEGER, v_after INTEGER, result TEXT, at_ms INTEGER)""")


def save(con, match_id, delta, v_before, v_after, result):
    ensure_table(con)
    con.execute("INSERT OR REPLACE INTO lp_game VALUES (?,?,?,?,?,?)",
                (match_id, int(delta), v_before, v_after, result, int(time.time() * 1000)))
    con.commit()


def known(con):
    """{match_id: (delta, result)} das partidas medidas pelo vigia."""
    try:
        ensure_table(con)
        return {r[0]: (r[1], r[2]) for r in con.execute("SELECT match_id, delta, result FROM lp_game")}
    except Exception:
        return {}


def typical(con, n=20):
    """(ganho medio, perda media) das ultimas partidas medidas; None se ainda tiver pouca coisa."""
    try:
        ensure_table(con)
        rows = con.execute("SELECT delta, result FROM lp_game WHERE result IN ('win','loss') ORDER BY at_ms DESC LIMIT ?",
                           (n * 2,)).fetchall()
    except Exception:
        return None
    w = [r[0] for r in rows if r[1] == "win" and 0 < r[0] < 60][:n]
    l = [-r[0] for r in rows if r[1] == "loss" and -60 < r[0] < 0][:n]
    if len(w) < 3 or len(l) < 3:
        return None
    med = lambda xs: sorted(xs)[len(xs) // 2]
    return med(w), med(l)


def _v(rs):
    return ranks.ladder(rs.get("tier"), rs.get("division"), rs.get("lp")) if rs else None


def _cnt(rs):
    return (rs.get("wins") or 0) + (rs.get("losses") or 0) if rs else None


def _platform(region):
    return (region or "br1").upper()


def step(st, client, con, region, now=None):
    """Um passo do vigia (separado para teste). st guarda o estado entre os passos."""
    now = now or time.time()
    ph = client.gameflow_phase()
    rs = None
    if ph not in ("InProgress", "GameStart", "Reconnect"):
        rs = client.ranked_solo()
        if rs and rs.get("lp") is not None:
            ranks.record(con, rs["tier"], rs["division"], rs["lp"], rs["wins"], rs["losses"])
            if not st.get("pending"):
                st["last"] = rs
    if ph in ("ChampSelect", "GameStart", "InProgress") and not st.get("pending"):
        try:
            status, sess = client.request("GET", "/lol-gameflow/v1/session")
        except Exception:
            status, sess = 0, None
        gd = (sess or {}).get("gameData") or {} if status == 200 and isinstance(sess, dict) else {}
        gid = gd.get("gameId")
        q = ((gd.get("queue") or {}).get("id"))
        if ph in ("GameStart", "InProgress") and gid and q == 420 and st.get("last"):
            st["pending"] = {"gid": int(gid), "before": st["last"], "since": now, "ended": None}
    p = st.get("pending")
    if not p:
        return None
    if ph in ("InProgress", "GameStart", "Reconnect"):
        return None
    if p["ended"] is None:
        p["ended"] = now
    mid = f"{_platform(region)}_{p['gid']}"
    # 1) aviso de PDL do proprio cliente (quando existir e for desta partida)
    try:
        status, n = client.request("GET", "/lol-ranked/v1/current-lp-change-notification")
        if status == 200 and isinstance(n, dict) and int(n.get("gameId") or 0) == p["gid"] and n.get("leaguePointsDelta") is not None:
            d = int(n["leaguePointsDelta"])
            after = rs or {}
            save(con, mid, d, _v(p["before"]), _v(after) if after else None, "win" if d > 0 else "loss" if d < 0 else "zero")
            st["pending"] = None
            st["last"] = rs or st.get("last")
            return mid, d
    except Exception:
        pass
    # 2) elo antes x depois (vitorias + derrotas precisam mudar em exatamente 1)
    if rs and _cnt(rs) == _cnt(p["before"]) + 1:
        won = (rs.get("wins") or 0) - (p["before"].get("wins") or 0) == 1
        d = (_v(rs) or 0) - (_v(p["before"]) or 0)
        save(con, mid, d, _v(p["before"]), _v(rs), "win" if won else "loss")
        st["pending"] = None
        st["last"] = rs
        return mid, d
    if now - p["ended"] > WAIT_AFTER_S:
        if rs and _cnt(rs) == _cnt(p["before"]):          # placar nao mudou: remake (ou partida nao contou)
            save(con, mid, 0, _v(p["before"]), _v(rs), "remake")
            st["pending"] = None
            st["last"] = rs
            return mid, 0
        st["pending"] = None                              # nao deu para medir: fica no estimado
    return None


def run(get_ctx, stop=None):
    """get_ctx() -> (con, region, puuid) do dono da conta ligada (ou None). Roda para sempre em segundo plano."""
    from . import lcu
    st = {}
    while not (stop and stop.is_set()):
        try:
            ctx = get_ctx()
            if ctx:
                con, region, puuid = ctx
                try:
                    client = lcu.LCU.discover()
                    if puuid and time.time() - st.get("who_at", 0) > 60:      # so a conta ligada ao app (nao a de um amigo)
                        st["who_at"] = time.time()
                        st["who_ok"] = ((client.current_summoner() or {}).get("puuid") == puuid)
                    if st.get("who_ok", True):
                        step(st, client, con, region)
                finally:
                    try:
                        con.close()
                    except Exception:
                        pass
        except Exception:
            pass
        time.sleep(POLL_S)


def start(get_ctx, stop=None):
    if _STARTED["t"]:
        return
    _STARTED["t"] = threading.Thread(target=run, args=(get_ctx, stop), daemon=True)
    _STARTED["t"].start()
