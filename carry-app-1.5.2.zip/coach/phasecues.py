"""Avisos de voz por fase da partida, vindos das aulas (coach/aulas.py). No maximo 1 por fase e por papel.

Nivel GAP no overlay (so em silencio, nunca em cima de aviso de objetivo) e desligavel em "Aulas por fase".
Chaves: aula_<id da licao>. Cada chave sai uma vez por partida (o overlay nunca repete a mesma chave).
"""
from . import aulas

# janela de tempo (segundos de jogo) em que o aviso da fase pode sair
JANELA = {"cedo": (150, 230), "meio": (845, 905), "tarde": (1505, 1565)}


def cues(pos, gt):
    """Lista [{k, t}] do momento (gt em segundos). Uma lição por fase: a primeira que serve ao seu papel."""
    out = []
    for fase, (a, b) in JANELA.items():
        if a <= gt <= b:
            esc = aulas.cues_for(fase, pos)
            # papel especifico primeiro; se nao ha, a geral
            esc.sort(key=lambda x: (0 if x["papel"] and pos in x["papel"] else 1))
            if esc:
                out.append({"k": "aula_" + esc[0]["id"], "t": esc[0]["voz"]})
    return out
