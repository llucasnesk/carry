"""Como usar o Carry: passo a passo OBRIGATORIO na primeira vez, para todo mundo.

Pedido do usuario: "deveria aparecer pela primeira vez obrigatoriamente para todo mundo, um passo a passo para ele ir
fazendo passo por passo, pra ser facil de usar". Antes existia um checklist que dava para esconder e um tour de 5
slides so de leitura.

Agora: ao abrir o Carry pela primeira vez (launcher ou Inicio), a pessoa cai aqui. Um passo por tela, com o botao que
faz a coisa, o sinal de pronto que o app confere sozinho e o Proximo. Passos opcionais tem "Fazer depois". So libera
o app quando chega no fim (conta do LoL vinculada e, para o admin, a chave da Riot salva).
Enquanto nao terminar, uma faixa embaixo de toda pagina leva de volta ao passo em que parou.
"""
import html

e = lambda x: html.escape("" if x is None else str(x))


def steps(st):
    """[(chave, titulo, texto, itens, pronto, obrigatorio, (link, botao) ou None)] conforme o estado st."""
    admin = st.get("admin")
    out = [
        ("ola", "Bem-vindo ao Carry",
         "O Carry é o seu coach de League of Legends. Ele trabalha em 4 momentos de cada partida e você não precisa "
         "abrir nada no meio do jogo:",
         ["Seleção de campeões: counters, ban e runas montadas sozinhas no cliente.",
          "Tela de carregamento: a voz lê todos os jogadores (elo, main, sequência, duo, caçador que ganka cedo).",
          "Partida: o overlay mostra o próximo item e a voz avisa só o que muda a jogada.",
          "Depois: cada morte analisada, PDL real de cada partida e o que treinar."],
         True, True, None),
    ]
    if admin:
        out.append(("chave", "Chave da Riot",
                    "É ela que deixa o Carry ler as partidas (API oficial da Riot). Pegue em developer.riotgames.com, "
                    "entre com a sua conta da Riot e copie a Development API Key. Ela vence em 24 horas: o app avisa quando precisar trocar.",
                    ["Abra Administração, cole a chave e salve.", "Volte aqui: este passo fica pronto sozinho."],
                    st.get("has_key"), True, ("/admin", "Colocar a chave")))
    else:
        out.append(("chave", "Chave da Riot",
                    "Quem administra o Carry coloca a chave da Riot. Você não precisa fazer nada aqui.",
                    [], True, False, None))
    out += [
        ("conta", "Vincule a sua conta do LoL",
         "Digite o seu Riot ID (nome#TAG) e a região. O Carry confere com a Riot que a conta é sua.",
         ["Exemplo: ZED KING#zedly, região Brasil."],
         st.get("puuid"), True, ("/vincular", "Vincular conta")),
        ("sync", "Baixe as suas partidas",
         "Na primeira vez o Carry baixa as suas últimas ranqueadas (leva alguns minutos e roda em segundo plano). "
         "Depois ele sincroniza sozinho a cada partida.",
         ["Pode seguir para o próximo passo enquanto baixa."],
         st.get("games", 0) > 0 or st.get("syncing"), True, ("/sincronizar", "Sincronizar agora")),
        ("main", "Escolha o seu main",
         "O campeão que você mais joga. É por ele que o Carry escolhe build, runas, confrontos e o que treinar.",
         ["Dá para trocar quando quiser em Meu perfil."],
         st.get("main_ok"), False, None),
        ("overlay", "Ligue o overlay e a voz",
         "O overlay é a janela pequena por cima do jogo (próximo item, recargas do oponente, balão). A voz fala só o "
         "necessário: a leitura dos jogadores no carregamento, caçador perto de você, objetivo chegando e item pronto.",
         ["Atalho Ctrl+Shift+R: repete o último aviso.", "Atalho Ctrl+Shift+S: silencia a voz por 2 minutos.",
          "Em Editar overlay você liga e desliga cada tipo de aviso e muda o tamanho e a posição."],
         st.get("overlay"), False, ("/overlay", "Abrir Editar overlay")),
        ("mic", "Pergunte por voz (opcional)",
         "No jogo, segure o botão de falar e pergunte: \"o que eu compro?\", \"posso lutar?\", ou avise \"Zed usou Flash\" "
         "que o Carry conta o tempo e avisa quando voltar.",
         ["Em Editar overlay, escolha o botão de falar e teste o microfone."],
         st.get("mic"), False, ("/overlay", "Testar o microfone")),
    ]
    if admin:
        out.append(("ia", "Coach IA (opcional)",
                    "Com a chave grátis do Gemini (aistudio.google.com) o Coach IA responde perguntas sobre as suas partidas "
                    "e analisa cada morte depois do jogo.",
                    ["Abra Administração, cole a chave do Gemini e salve."],
                    st.get("ai"), False, ("/admin", "Colocar a chave do Gemini")))
    out.append(("jogar", "Como jogar com o Carry",
                "É sempre o mesmo caminho, e o Carry faz o resto sozinho:",
                ["1. Abra o Carry (o atalho na área de trabalho) e clique em JOGAR: ele abre o LoL e liga o overlay.",
                 "2. Na seleção, ouça o ban e o counter; as runas entram sozinhas quando você locka.",
                 "3. No carregamento, ouça a leitura dos jogadores (termina antes dos minions chegarem).",
                 "4. Depois da partida, abra o Pós-jogo: mortes analisadas, PDL real e o treino do dia.",
                 "Este passo a passo fica em Conta > Como usar, se quiser rever."],
                True, True, None))
    return out


def first_open(st):
    """Indice do primeiro passo obrigatorio que ainda falta (ou o ultimo)."""
    ss = steps(st)
    for i, s in enumerate(ss):
        if s[5] and not s[4]:
            return i
    return len(ss) - 1


def can_finish(st):
    return all(s[4] for s in steps(st) if s[5])


CSS = """
.cm{display:grid;grid-template-columns:280px minmax(0,1fr);gap:22px;max-width:1120px;margin:10px auto 40px}
.cm-l{border:1px solid #232323;background:#0B0B0B;padding:14px 0;align-self:start;position:sticky;top:10px}
.cm-l b{display:block;padding:0 18px 10px;font:700 11px 'CP','Bahnschrift',monospace;letter-spacing:.18em;color:#9A9A9A}
.cm-l a{display:flex;align-items:center;gap:12px;padding:10px 18px;text-decoration:none;color:#BDBDBD;font-size:14px;border-left:3px solid transparent}
.cm-l a:hover{color:#fff;background:#121212}.cm-l a.on{color:#fff;border-left-color:#E10600;background:#141010}
.cm-l a i{font-style:normal;flex:none;width:26px;height:26px;display:flex;align-items:center;justify-content:center;border:1px solid #3A3A3A;font:700 12px 'CP',monospace;color:#CFCFCF}
.cm-l a.ok i{background:#E10600;border-color:#E10600;color:#fff}.cm-l a small{display:block;color:#777;font-size:11.5px}
.cm-c{border:1px solid #2A2A2A;border-top:4px solid #E10600;background:#0E0E0E;padding:34px 38px 30px;min-height:420px;display:flex;flex-direction:column}
.cm-k{margin:0 0 6px;font:700 12px 'CP','Bahnschrift',monospace;letter-spacing:.18em;color:#A8A8A8}
.cm-c h2{margin:0 0 14px;font:800 38px/1.04 'BC','Bahnschrift','Arial Narrow',sans-serif;text-transform:uppercase;color:#fff}
.cm-c p.t{margin:0 0 16px;color:#DADADA;font-size:16px;line-height:1.55;max-width:70ch}
.cm-c ul{margin:0 0 20px;padding:0;list-style:none;display:grid;gap:8px}.cm-c li{position:relative;padding-left:18px;color:#CFCFCF;line-height:1.5}
.cm-c li::before{content:'';position:absolute;left:0;top:.6em;width:7px;height:7px;background:#E10600;transform:rotate(45deg)}
.cm-st{display:flex;align-items:center;gap:12px;border:1px solid #333;background:#161616;padding:14px 18px;margin:4px 0 22px}
.cm-st span{width:12px;height:12px;border-radius:50%;background:#555;flex:none}.cm-st.ok span{background:#3DBE8B;box-shadow:0 0 0 4px rgba(61,190,139,.18)}
.cm-st.wait span{background:#E10600;animation:cmp 1.4s infinite}@keyframes cmp{50%{opacity:.35}}
.cm-st b{font:700 15px 'BL',sans-serif;color:#fff}.cm-st small{color:#9A9A9A}
.cm-b{margin-top:auto;display:flex;gap:12px;flex-wrap:wrap;align-items:center}
.cm-b a,.cm-b button{height:52px;padding:0 26px;display:inline-flex;align-items:center;justify-content:center;font:700 14px 'CP','Bahnschrift',monospace;
letter-spacing:.06em;text-transform:uppercase;text-decoration:none;cursor:pointer}
.cm-go{background:#E10600;border:0;color:#fff}.cm-go:hover{background:#FF1A0D}.cm-go[aria-disabled=true]{background:#3A1A1A;color:#8A6A6A;pointer-events:none}
.cm-sec{background:transparent;border:1px solid #444;color:#EDEDED}.cm-sec:hover{border-color:#888}
.cm-skip{margin-left:auto;color:#9A9A9A;font-size:13px;text-decoration:underline;background:none;border:0;height:auto;padding:0;text-transform:none;letter-spacing:0;font-family:'BL',sans-serif}
.cm-bar{height:4px;background:#222;margin:0 0 24px}.cm-bar i{display:block;height:100%;background:#E10600}
.cm-extra{margin:0 0 20px}
@media (max-width:900px){.cm{grid-template-columns:1fr}.cm-l{position:static}}
"""


def page_html(st, i, extra_html=""):
    ss = steps(st)
    i = max(0, min(i, len(ss) - 1))
    k, title, text, items, ok, req, act = ss[i]
    nav = "<nav class='cm-l' aria-label='Passos'><b>COMO USAR O CARRY</b>" + "".join(
        f"<a href='/comecar?p={n}' class='{'on ' if n == i else ''}{'ok' if s[4] else ''}'{' aria-current=step' if n == i else ''}>"
        f"<i>{'&#10003;' if s[4] else n + 1}</i><span>{e(s[1])}<small>{'pronto' if s[4] else ('obrigatório' if s[5] else 'opcional')}</small></span></a>"
        for n, s in enumerate(ss)) + "</nav>"
    lis = "".join(f"<li>{e(x)}</li>" for x in items)
    if k in ("ola", "jogar") or (k == "chave" and not st.get("admin")):
        status = ""
    else:
        status = (f"<div class='cm-st {'ok' if ok else 'wait'}'><span></span><div><b>{'Pronto' if ok else 'Falta fazer'}</b>"
                  f"<small> · {'o Carry já conferiu' if ok else 'esta tela confere sozinha a cada poucos segundos'}</small></div></div>")
    last = i == len(ss) - 1
    btns = ""
    if act and not ok:
        btns += f"<a class='cm-go' href='{e(act[0])}'>{e(act[1])}</a>"
    elif act:
        btns += f"<a class='cm-sec' href='{e(act[0])}'>{e(act[1])}</a>"
    if i > 0:
        btns += f"<a class='cm-sec' href='/comecar?p={i - 1}'>Voltar</a>"
    if last:
        fin = can_finish(st)
        btns += ("<form method='post' action='/comecar/fim' style='margin:0'><button class='cm-go'"
                 + ("" if fin else " aria-disabled='true' disabled") + ">Concluir e abrir o Carry</button></form>")
        if not fin:
            btns += f"<a class='cm-sec' href='/comecar?p={first_open(st)}'>Ir ao passo que falta</a>"
    else:
        blocked = req and not ok
        btns += (f"<a class='{'cm-sec' if act and not ok else 'cm-go'}' href='/comecar?p={i + 1}'"
                 + (" aria-disabled='true'" if blocked else "") + f">{'Próximo' if not blocked else 'Faça este passo para seguir'}</a>")
        if not req and not ok:
            btns += f"<a class='cm-skip' href='/comecar?p={i + 1}'>Fazer depois</a>"
    pct = round(100 * sum(1 for s in ss if s[4]) / len(ss))
    poll = ("" if ok or k in ("ola", "jogar") else
            "<script>(function(){var t=setInterval(function(){if(document.hidden)return;"
            "fetch(location.href,{cache:'no-store'}).then(function(r){return r.text()}).then(function(h){"
            "if(h.indexOf(\"cm-st ok\")>-1){clearInterval(t);location.reload()}}).catch(function(){})},5000)})()</script>")
    return (f"<style>{CSS}</style><div class='cm'>{nav}<section class='cm-c' aria-live='polite'>"
            f"<div class='cm-bar' aria-hidden='true'><i style='width:{pct}%'></i></div>"
            f"<p class='cm-k'>PASSO {i + 1} DE {len(ss)}</p><h2>{e(title)}</h2><p class='t'>{e(text)}</p>"
            + (f"<ul>{lis}</ul>" if lis else "") + (f"<div class='cm-extra'>{extra_html}</div>" if extra_html else "")
            + f"{status}<div class='cm-b'>{btns}</div></section></div>{poll}")


def back_bar(step):
    """Faixa fixa embaixo das outras paginas enquanto o passo a passo nao terminou."""
    return ("<a href='/comecar?p=" + str(int(step or 0)) + "' style='position:fixed;left:50%;bottom:16px;transform:translateX(-50%);z-index:900;"
            "display:flex;align-items:center;gap:12px;background:#E10600;color:#fff;text-decoration:none;padding:12px 22px;"
            "font:700 13px \"CP\",\"Bahnschrift\",monospace;letter-spacing:.06em;text-transform:uppercase;box-shadow:0 10px 30px rgba(0,0,0,.5)'>"
            "&#8592; Voltar ao passo a passo</a>")
