"""Aulas: decisoes que fazem subir de elo (objetivos, fases, recall, selva, suporte, play da vitoria, itens, cabeca).

Fonte UNICA de conteudo: a pagina /aulas, o plano de partida (pos-jogo) e os avisos por fase usam as mesmas licoes.
Texto reescrito com palavras do app. Conferido para a temporada 2026 (patch 26.x): Atakhan saiu do jogo, epicos tem ~15% mais vida,
o teleporte foi empurrado para chegar em lutas. Tempos do mapa: gametimes.py.

Cada licao: id, tema, titulo, texto, fase ("cedo" 0-14, "meio" 14-25, "tarde" 25+, "sempre"), papel (None = todos ou lista),
elo (indice minimo, maximo em ELOS), medida (chave de coach/plano.py ou None), voz (frase curta para o aviso da fase, ou None).
"""
import html

e = lambda x: html.escape("" if x is None else str(x))

ELOS = ["IRON", "BRONZE", "SILVER", "GOLD", "PLATINUM", "EMERALD", "DIAMOND", "MASTER", "GRANDMASTER", "CHALLENGER"]
ELO_PT = {"IRON": "Ferro", "BRONZE": "Bronze", "SILVER": "Prata", "GOLD": "Ouro", "PLATINUM": "Platina", "EMERALD": "Esmeralda",
          "DIAMOND": "Diamante", "MASTER": "Mestre", "GRANDMASTER": "Grão-Mestre", "CHALLENGER": "Desafiante"}

TEMAS = [
    ("objetivos", "Objetivos", "O que vale ficar, o que vale largar."),
    ("fases", "As fases da partida", "O que fazer em cada momento."),
    ("recall", "Recall, TP e compras", "Quando voltar e quando não."),
    ("lane", "Começo de rota", "O que não muda de temporada."),
    ("selva", "Selva", "Ritmo, câmera e quem ajudar."),
    ("suporte", "Suporte", "Visão e presença."),
    ("vitoria", "A jogada da vitória", "Como o seu campeão fecha o jogo."),
    ("itens", "Itens", "Regras de compra que servem para todos."),
    ("cabeca", "Elo e cabeça", "Hábitos que seguram o seu PDL."),
]


def L(id, tema, titulo, texto, fase="sempre", papel=None, elo=(0, 9), medida=None, voz=None):
    return {"id": id, "tema": tema, "titulo": titulo, "texto": texto, "fase": fase, "papel": papel, "elo": elo, "medida": medida, "voz": voz}


LICOES = [
    # --- objetivos
    L("obj_ouro", "objetivos", "Ouro volta, objetivo não",
      "Ouro perdido você recupera na próxima onda. Dragão, alma e larvas ficam com o outro time para sempre. Quando a troca é um abate seu contra um objetivo "
      "deles, quase sempre vale perder o abate e ficar com o objetivo.", elo=(2, 9), medida="objetivos"),
    L("obj_larvas", "objetivos", "Larvas servem para ouro, não para largar a lane",
      "As larvas dão ouro e pressão de torre, mas não valem abandonar uma rota que você está ganhando. Se o seu atirador está vencendo, deixe ele farmar "
      "e vá nas larvas só com quem está livre.", fase="cedo", papel=["JUNGLE", "UTILITY"]),
    L("obj_lado", "objetivos", "Na side enquanto o time luta objetivo é erro",
      "Se o seu time está lutando pelo dragão ou barão e você está sozinho na rota, o objetivo fica 4 contra 5. Chegue antes ou fique de fora: a side só "
      "vale se o inimigo também ficou lá.", fase="meio", medida="objetivos", voz="Objetivo chegando: venha para o time."),
    L("obj_inimigo_side", "objetivos", "Inimigo na side e você no objetivo é bom",
      "Se um inimigo está sozinho na rota e o seu time está no objetivo, o time dele não tem como responder. Faça o objetivo rápido e só depois olhe a torre.",
      fase="meio", elo=(3, 9)),
    L("obj_epicos", "objetivos", "Epicos aguentam mais em 2026",
      "Dragão, barão e Arauto têm cerca de 15% a mais de vida nesta temporada e o dragão ganha defesa extra a cada dragão que o time acumula. Entrar para "
      "só começar a bater com o time atrasado costuma perder a luta; prepare visão e entre junto.", fase="meio", elo=(3, 9)),
    # --- fases
    L("fase_cedo", "fases", "0 a 14 min: farm e experiência",
      "Nos primeiros 14 minutos o seu trabalho é farmar e ganhar nível. Abate cedo custa pouco (uma onda), mas uma morte atrasa o seu pico de poder. "
      "Chegar aos 14 minutos farmado e com ouro acumulado é o que deixa você ir direto ao dragão sem recall.", fase="cedo", medida="farm14", voz="Cedo: farm e experiência. Não force abate."),
    L("fase_14", "fases", "14 min: hora de se reunir",
      "Aos 14 minutos a fase de rotas acaba e o dragão passa a decidir o jogo. Chegue ao objetivo com 1 minuto de antecedência, "
      "com visão colocada, estando forte ou fraco: quem chega antes escolhe o lugar da luta.", fase="meio", elo=(2, 9), medida="objetivos", voz="14 minutos: junte com o time e vá ao dragão."),
    L("fase_meio", "fases", "14 a 25 min: chegue 1 minuto antes",
      "Entre 14 e 25 minutos todo objetivo é uma luta marcada. Dê o recall com tempo, compre, e esteja na posição um minuto antes do objetivo nascer. "
      "Quem chega depois entra na luta já atrasado e sem visão.", fase="meio", medida="objetivos", voz="Meio de jogo: chegue ao objetivo um minuto antes."),
    L("fase_tarde", "fases", "Depois dos 25: não se separe",
      "A partir dos 25 minutos um abate sozinho no mapa decide o jogo. Evite campinho, evite side sem visão e só responda a onda que vai para o meio, "
      "agrupando com o time logo depois. Pegar o inimigo isolado é o plano; se ninguém está isolado, espere.", fase="tarde", elo=(2, 9), medida="mortes_tarde", voz="Depois dos 25: não se separe. Procure abate isolado."),
    # --- recall / tp
    L("rec_objetivo", "recall", "Não dê recall para comprar enquanto o time luta objetivo",
      "Se o seu time está no dragão ou no barão, voltar para comprar um item deixa a luta 4 contra 5. Item novo não compensa um objetivo perdido; "
      "compre depois ou faça o recall antes de o objetivo estar para nascer.", fase="meio", medida="recall_obj"),
    L("rec_tp", "recall", "Teleporte em 2026 é para chegar na luta e defender",
      "Esta temporada o Riot empurrou o teleporte para jogadas de longe, chegar no objetivo ou defender uma torre, e longe de usar só para voltar à rota. "
      "Se você o tem, guarde para um momento que muda o jogo (luta de dragão, torre sob pressão) em vez de gastar logo depois de voltar da base.",
      fase="meio", papel=["TOP", "MIDDLE"], elo=(2, 9)),
    L("rec_primeira", "recall", "Primeira volta: a melhor compra",
      "Na primeira volta compre o item mais forte que o ouro permite, uma sentinela de controle e tudo de uma vez. Voltar duas vezes por falta de ouro "
      "custa duas ondas.", fase="cedo", medida="primeiro_recall"),
    # --- lane
    L("lane_doran", "lane", "Doran no início paga o jogo todo",
      "O item Doran dá vida, dano e recuperação que valem mais do que o ouro gasto. Comece com ele, mantenha o Doran no inventário o jogo inteiro "
      "e só troque se o inventário lotar.", fase="cedo", elo=(0, 5), voz=None),
    # --- selva
    L("sel_ritmo", "selva", "Power farm até 13–14 min",
      "O caçador cresce farmando campos: faça o circuito completo, entre numa rota só quando for ganhar abate ou objetivo. Perto dos 13–14 minutos pegue os "
      "bônus (azul/vermelho) e fique com o time.", fase="cedo", papel=["JUNGLE"], medida="farm14", voz="Caçador: power farm. Gank só se for certeiro."),
    L("sel_camera", "selva", "Câmera nas rotas",
      "Olhe com frequência o minimapa e as três rotas para decidir o próximo gank. O melhor gank é na rota que tem onda empurrando e o inimigo sem fuga.",
      papel=["JUNGLE"], elo=(0, 9)),
    L("sel_ping", "selva", "Avise a rota: a caminho",
      "Mande o ping de 'a caminho' quando decidir ir. A rota que sabe que o caçador vem joga o abate com você; sem aviso, ela trava ou foge.",
      papel=["JUNGLE"], elo=(0, 5)),
    L("sel_carregar", "selva", "Jogue para quem pode carregar",
      "Gaste o seu tempo em quem consegue virar o jogo (a rota que está ganhando, o campeão que escala). Ajudar quem já está perdendo feio rende pouco; "
      "o melhor do time vira o ouro mais usado.", papel=["JUNGLE"], elo=(1, 9)),
    L("sel_tilt", "selva", "Silencie quem tilta",
      "Se um aliado está xingando ou discutindo, silencie o chat dele e siga o plano. Uma discussão custa mais partidas do que um gank errado.",
      papel=["JUNGLE"], elo=(0, 9)),
    L("sel_leque", "selva", "Nível 1: abra em leque",
      "Abra no nível 1 para os lados, sem invadir sem informação. Invadir é perder tempo de farm se o outro caçador estiver do outro lado.",
      fase="cedo", papel=["JUNGLE"], elo=(2, 9)),
    L("sel_opgg", "selva", "Olhe o perfil do time antes",
      "Na seleção, confira o perfil do seu time: campeões em que cada um é bom e quem joga só um campeão. Isso mostra quem é o carregador e a rota para jogar.",
      papel=["JUNGLE"], fase="cedo", elo=(0, 4)),
    # --- suporte
    L("sup_meio", "suporte", "Sem sentinela no meio da rota",
      "Sentinela no meio da rota some em uma onda. Coloque no arbusto de ataque, atrás do inimigo ou no rio, onde ela dura e mostra o caçador.",
      fase="cedo", papel=["UTILITY"], medida="ward_lane"),
    L("sup_avancada", "suporte", "Primeira volta: sentinela avançada",
      "Na primeira volta compre sentinela e coloque uma avançada na frente do rio. É o aviso que mais salva a sua rota nos próximos 5 minutos.",
      fase="cedo", papel=["UTILITY"], elo=(0, 9), voz=None),
    L("sup_caranguejo", "suporte", "Caranguejo e ponta do rio",
      "Controle o caranguejo e a ponta do rio com o seu caçador. Visão ali dá direito ao dragão ou ao Arauto sem ninguém tentar roubar.", papel=["UTILITY"], fase="meio"),
    L("sup_cura", "suporte", "Em elo baixo, suporte que cura",
      "Do Ferro ao Ouro, suporte que protege e cura rende mais do que um que só faz dano: a rota luta mais e erra menos. Suba de elo primeiro, aprenda os de poke depois.",
      papel=["UTILITY"], elo=(0, 3)),
    # --- vitoria
    L("vit_assassino", "vitoria", "Assassino: guarde o salto para o alvo decisivo",
      "Com assassino, o flash e o combo são para o alvo que decide a luta (o carregador, o mago). Não gaste no primeiro que aparecer: fique no arbusto "
      "um minuto antes do objetivo e entre quando o alvo gastar o escape.", fase="meio", papel=["MIDDLE", "TOP", "JUNGLE"], medida="mortes_meio",
      voz="Assassino: guarde o flash para o alvo que decide."),
    L("vit_um_dois", "vitoria", "No máximo 1–2 abates por luta",
      "Assassino entra para pegar um ou dois alvos e sair. Tentar o terceiro costuma custar a sua vida e a luta inteira.", papel=["MIDDLE", "TOP", "JUNGLE"], fase="tarde", elo=(3, 9)),
    L("vit_time_perto", "vitoria", "Entre com o time por perto",
      "Entrar sozinho em quatro inimigos não é flanquear, é perder. O plano é o seu time puxar a atenção, e você entrar nos 3 segundos seguintes.",
      papel=["MIDDLE", "TOP", "JUNGLE"], fase="meio", elo=(2, 9)),
    L("vit_ga", "vitoria", "Contra dano físico, a armadura que ressuscita",
      "Se o time deles é dano físico, o Anjo Guardião é a compra que faz você sair das lutas vivo; em dano mágico compre o véu antes.", papel=["MIDDLE", "TOP", "JUNGLE", "BOTTOM"],
      fase="tarde", elo=(3, 9)),
    L("vit_lutador", "vitoria", "Lutador: chegue 1 min antes e faça corpo",
      "Com lutador, esteja na posição do objetivo um minuto antes e fique na frente para o suporte e o atirador baterem sem ser alcançados. "
      "O inimigo que chegou da side chega atrasado.", fase="meio", papel=["TOP", "JUNGLE", "UTILITY"], voz="Lutador: chegue 1 min antes e faça corpo."),
    # --- itens
    L("it_pen", "itens", "Penetração a partir do 3º item",
      "Com dano de mago ou assassino, o 3º item já é hora de penetração, porque os inimigos aumentam a defesa. Antes disso o dano bruto rende mais.",
      fase="meio", papel=["MIDDLE", "BOTTOM", "JUNGLE", "TOP"], elo=(2, 9)),
    L("it_gume", "itens", "Gume do Infinito depende de crítico",
      "O Gume só vale se você já tem outros itens de crítico: ele é um multiplicador, não um item de dano sozinho. Sem crítico suficiente, compre outro dano.",
      papel=["BOTTOM"], fase="meio", elo=(3, 9)),
    L("it_escudo", "itens", "3 ou mais escudos: compre corta-escudo",
      "Se o inimigo tem 3 ou mais escudos e curas, compre o item que reduz isso. Senão o seu dano some em cada luta.", fase="tarde", elo=(3, 9)),
    L("it_rei", "itens", "Rei Destruído é para lutador e atirador, não tanque",
      "O Rei Destruído dá dano pela vida do alvo: ótimo com atirador e lutador, desperdício em tanque.", papel=["TOP", "BOTTOM", "JUNGLE"], elo=(3, 9)),
    L("it_letal", "itens", "Letalidade para matar sozinho",
      "Quem joga atrás de abates de um só ataque (assassino) ganha mais com letalidade; contra time cheio de vida e tanque, passe para a penetração percentual.",
      papel=["MIDDLE", "JUNGLE"], elo=(3, 9)),
    # --- cabeca
    L("cab_mono", "cabeca", "Jogue poucos campeões",
      "Quem sobe mais rápido concentra em 1–3 campeões e conhece cada troca. Experimente campeão novo fora da ranqueada.", elo=(0, 5)),
    L("cab_aram", "cabeca", "1–2 ARAM por dia, não mais",
      "ARAM treina luta de equipe e ritmo, mas não ensina rota ou mapa. Use para aquecer e para espairecer, com limite de uma ou duas partidas por dia.", elo=(0, 5)),
    L("cab_replay", "cabeca", "Revise as suas derrotas",
      "Assistir a derrota inteira e anotar três mortes que você podia evitar ensina mais do que dez partidas novas. O Carry já separa os momentos para você.",
      elo=(0, 9)),
    L("cab_basico", "cabeca", "Arroz com feijão",
      "O básico (farm, visão, não morrer, ir ao objetivo) ganha mais partidas do que a jogada bonita. Se você erra no básico, a jogada bonita não aparece.",
      elo=(0, 5)),
    L("cab_streak", "cabeca", "Sequência de derrotas: pare",
      "Duas derrotas seguidas: pare por um tempo. A terceira partida sob tilt perde mais PDL do que uma hora de descanso. Foque no que você controla (o seu jogo), "
      "não no time.", elo=(0, 9)),
    L("cab_controle", "cabeca", "Controle só o que é seu",
      "Você não decide o campeão do aliado nem o humor do chat; decide a sua posição, o seu farm e a sua decisão no objetivo. Gaste a atenção nisso.", elo=(0, 9)),
]

# Foco por faixa de elo: quais licoes aparecem em destaque na trilha (ids, na ordem)
TRILHA = {
    "iniciante": ["cab_basico", "cab_mono", "fase_cedo", "lane_doran", "rec_primeira", "cab_streak"],      # Ferro-Bronze
    "meio": ["fase_cedo", "fase_14", "obj_ouro", "rec_objetivo", "sup_meio", "sel_ritmo", "cab_replay"],  # Prata-Ouro
    "alto": ["fase_meio", "obj_lado", "obj_inimigo_side", "vit_assassino", "vit_um_dois", "fase_tarde", "it_pen"],  # Platina-Esmeralda
    "elite": ["fase_tarde", "vit_time_perto", "obj_epicos", "vit_ga", "it_escudo", "cab_controle"],        # Diamante+
}


def faixa(tier):
    """Faixa da trilha para um elo (ou 'meio' se desconhecido)."""
    try:
        i = ELOS.index((tier or "").upper())
    except ValueError:
        return "meio"
    return "iniciante" if i <= 1 else "meio" if i <= 3 else "alto" if i <= 5 else "elite"


def by_id(lid):
    return next((x for x in LICOES if x["id"] == lid), None)


def for_player(tier, position=None):
    """Licoes na ordem da trilha do elo, so as que servem para o papel do jogador."""
    out = []
    for lid in TRILHA[faixa(tier)]:
        x = by_id(lid)
        if x and (not x["papel"] or position in x["papel"] or not position):
            out.append(x)
    return out


def cues_for(fase, position=None):
    """Licoes com frase de voz para uma fase ('cedo','meio','tarde'), filtradas por papel."""
    return [x for x in LICOES if x["voz"] and x["fase"] == fase and (not x["papel"] or position in x["papel"])]


CSS = """
.au-hero{border:1px solid rgba(233,196,106,.4);border-radius:18px;padding:18px 22px;background:radial-gradient(800px 240px at 0 0,rgba(233,196,106,.1),transparent 70%),var(--panel);margin-bottom:16px}
.au-hero h2{margin:0 0 6px;font:800 24px var(--head);color:#fff}.au-hero p{margin:4px 0;color:#E8DCCB;font-size:14.5px;line-height:1.55}
.au-trilha{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:12px;margin:12px 0 0}
.au-c{border:1px solid var(--rule);border-radius:14px;padding:13px 15px;background:rgba(255,255,255,.03)}
.au-c b{display:block;color:var(--gold);font:700 14px var(--head);margin-bottom:5px}.au-c p{margin:0;color:#E8DCCB;font-size:13.5px;line-height:1.55}
.au-sec{border:1px solid var(--rule);border-radius:18px;padding:16px 20px;background:var(--panel);margin:14px 0}
.au-sec h2{margin:0 0 2px;font:700 20px var(--head);color:#fff}.au-sec>p.s{margin:0 0 10px;color:#9A8F86;font-size:13px}
.au-sec details{border:1px solid rgba(255,255,255,.07);border-radius:10px;padding:9px 12px;margin:7px 0;background:rgba(255,255,255,.02)}
.au-sec summary{cursor:pointer;font-weight:600;color:#fff;font-size:14.5px}.au-sec details p{margin:8px 0 2px;color:#E8DCCB;font-size:14px;line-height:1.6}
.au-ch{display:inline-block;margin:0 6px 0 0;padding:1px 8px;border-radius:999px;font:700 11px var(--head);background:rgba(233,196,106,.15);color:var(--gold)}
.au-f{margin:16px 0 0;font-size:12.5px;color:#9A8F86}
"""

PAPEL_PT = {"TOP": "Topo", "JUNGLE": "Selva", "MIDDLE": "Meio", "BOTTOM": "Atirador", "UTILITY": "Suporte"}
FASE_PT = {"cedo": "0–14 min", "meio": "14–25 min", "tarde": "25+ min", "sempre": "o jogo todo"}


def _item(x, open_=False):
    chips = f"<span class='au-ch'>{e(FASE_PT[x['fase']])}</span>"
    if x["papel"]:
        chips += "".join(f"<span class='au-ch'>{e(PAPEL_PT.get(p, p))}</span>" for p in x["papel"])
    return (f"<details id='{e(x['id'])}'{' open' if open_ else ''}><summary>{e(x['titulo'])}</summary><p>{chips}</p><p>{e(x['texto'])}</p></details>")


def page_html(tier=None, position=None):
    """Pagina /aulas: trilha do seu elo e todas as licoes por tema."""
    fx = faixa(tier)
    nome = ELO_PT.get((tier or "").upper(), "seu elo")
    trilha = for_player(tier, position)
    cards = "".join(f"<a class='au-c' href='#{e(x['id'])}' style='text-decoration:none'><b>{e(x['titulo'])}</b><p>{e(x['texto'][:150])}…</p></a>" for x in trilha)
    hero = (f"<div class='au-hero'><h2>Para o seu elo: {e(nome)}</h2><p>Estas são as lições que mais rendem agora"
            f"{' para ' + e(PAPEL_PT.get(position, position)) if position else ''}. Elas também viram avisos durante a partida e itens do <b>Plano da partida</b> depois do jogo.</p>"
            f"<div class='au-trilha'>{cards}</div></div>")
    secs = ""
    for tid, tt, sub in TEMAS:
        itens = [x for x in LICOES if x["tema"] == tid]
        if not itens:
            continue
        secs += f"<section class='au-sec' id='t-{tid}'><h2>{e(tt)}</h2><p class='s'>{e(sub)}</p>" + "".join(_item(x) for x in itens) + "</section>"
    js = ("<script>(function(){function o(){var d=document.getElementById((location.hash||'').slice(1));if(d&&d.tagName==='DETAILS'){d.open=true;d.scrollIntoView()}}"
          "addEventListener('hashchange',o);o()})()</script>")
    return f"<style>{CSS}</style>{hero}{secs}{js}<p class='au-f'>Regras gerais para a temporada 2026. Se um número mudar no patch, o app avisa na página Patch.</p>"
