"""Plano da partida: depois do jogo, mede na timeline se voce seguiu as aulas e liga cada item a licao.

So mede o que a timeline mostra com seguranca (farm aos 14, mortes por fase e se estava sozinho, presenca nos objetivos,
recall durante objetivo). Referencia de farm = amostra dos melhores guardada no app; sem amostra, nao inventa numero.
"""
import html as _html
import json
import math

e = lambda x: _html.escape("" if x is None else str(x))

# item medido -> licao de coach/aulas.py
LICAO = {"farm14": "fase_cedo", "mortes_cedo": "fase_cedo", "objetivos": "fase_meio", "mortes_meio": "vit_time_perto",
         "mortes_tarde": "fase_tarde", "recall_obj": "rec_objetivo"}

OBJ_TYPES = ("DRAGON", "BARON_NASHOR", "RIFTHERALD")
NEAR_OBJ = 3500        # distancia ao poco do objetivo para contar como presente
NEAR_ALLY = 2500       # aliado a menos disso = nao estava sozinho
BASE_R = 1800
FOUNTAIN = {100: (500, 500), 200: (14300, 14300)}
MIN_REF = 5            # partidas minimas da amostra para usar como referencia


def _dist(a, b):
    return math.hypot(a[0] - b[0], a[1] - b[1])


def _frames(con, mid):
    out = {}
    for pid, m, cs, x, y in con.execute("SELECT participant_id, minute, cs, x, y FROM frames WHERE match_id=?", (mid,)):
        out.setdefault(pid, {})[m] = (cs, x, y)
    return out


def _at(fr, pid, t_ms):
    """Foto mais proxima do instante (minuto inteiro) para o jogador, ou None."""
    d = fr.get(pid)
    if not d:
        return None
    m = min(d, key=lambda k: abs(k * 60000 - t_ms))
    if abs(m * 60000 - t_ms) > 90000 or d[m][1] is None:
        return None
    return d[m]


def _ref_cs14(con, position, champion):
    """Media de CS aos 14 min dos melhores no mesmo papel (do mesmo campeao se houver amostra)."""
    q = ("SELECT AVG(f.cs), COUNT(*) FROM frames f JOIN participants p ON p.match_id=f.match_id AND p.participant_id=f.participant_id "
         "JOIN match_source s ON s.match_id=f.match_id WHERE s.source='top' AND f.minute=14 AND p.position=?")
    for extra, args in ((" AND p.champion=?", (position, champion)), ("", (position,))):
        avg, n = con.execute(q + extra, args).fetchone()
        if avg is not None and n >= MIN_REF:
            return avg, n
    return None, 0


def _item(key, ok, titulo, detalhe):
    return {"key": key, "ok": ok, "titulo": titulo, "detalhe": detalhe, "licao": LICAO[key]}


def plan(con, puuid, mid):
    """Lista de itens medidos [{key, ok (True/False/None), titulo, detalhe, licao}]. [] se a partida nao tem timeline."""
    me = con.execute("SELECT participant_id, team_id, position, champion FROM participants WHERE match_id=? AND puuid=?", (mid, puuid)).fetchone()
    mt = con.execute("SELECT duration_s FROM matches WHERE match_id=?", (mid,)).fetchone()
    if not me or not mt:
        return []
    pid, team, pos, champ = me
    dur = mt[0] or 0
    fr = _frames(con, mid)
    if pid not in fr:
        return []
    allies = [p for (p,) in con.execute("SELECT participant_id FROM participants WHERE match_id=? AND team_id=? AND participant_id<>?", (mid, team, pid))]
    deaths = [t for (t,) in con.execute("SELECT t_ms FROM deaths WHERE match_id=? AND victim_id=? ORDER BY t_ms", (mid, pid))]
    out = []

    # farm aos 14
    if dur >= 14 * 60 and pos != "UTILITY" and 14 in fr[pid]:
        cs = fr[pid][14][0]
        ref, n = _ref_cs14(con, pos, champ)
        if ref is None:
            out.append(_item("farm14", None, "Farm aos 14 minutos", f"Você tinha {cs} CS aos 14. Ainda não há amostra dos melhores do seu papel para comparar."))
        else:
            out.append(_item("farm14", cs >= ref * 0.9, "Farm aos 14 minutos",
                             f"Você tinha {cs} CS aos 14; os melhores do seu papel têm cerca de {round(ref)} ({n} partidas)."))

    # mortes por fase (e se estava sozinho)
    def alone(t):
        mine = _at(fr, pid, t)
        if not mine:
            return None
        for a in allies:
            o = _at(fr, a, t)
            if o and _dist((mine[1], mine[2]), (o[1], o[2])) <= NEAR_ALLY:
                return False
        return True

    if dur >= 14 * 60:
        early = [t for t in deaths if t < 14 * 60000]
        out.append(_item("mortes_cedo", len(early) <= 1, "Mortes antes dos 14 minutos",
                         f"{len(early)} morte(s) antes dos 14." + (" Morrer cedo atrasa o seu pico de poder." if len(early) > 1 else "")))
    if dur >= 25 * 60:
        mid_d = [t for t in deaths if 14 * 60000 <= t < 25 * 60000]
        sol = [t for t in mid_d if alone(t)]
        out.append(_item("mortes_meio", len(sol) <= 1, "Mortes sozinho entre 14 e 25 min",
                         f"{len(sol)} de {len(mid_d)} mortes aconteceram sem nenhum aliado por perto."))
        late = [t for t in deaths if t >= 25 * 60000]
        sol = [t for t in late if alone(t)]
        out.append(_item("mortes_tarde", len(sol) == 0, "Mortes sozinho depois dos 25",
                         f"{len(sol)} de {len(late)} mortes aconteceram sem nenhum aliado por perto." if late else "Sem mortes depois dos 25 minutos."))

    # objetivos do seu time
    objs = []
    for t, tm, x, y, data in con.execute("SELECT t_ms, team_id, x, y, data FROM events WHERE match_id=? AND type='ELITE_MONSTER_KILL' ORDER BY t_ms", (mid,)):
        try:
            mt_ = json.loads(data or "{}").get("monsterType")
        except ValueError:
            continue
        if mt_ in OBJ_TYPES and t >= 5 * 60000 and x is not None and y is not None:
            objs.append((t, tm, (x, y)))
    mine_o = [o for o in objs if o[1] == team]
    if mine_o:
        pres = 0
        for t, _tm, xy in mine_o:
            f = _at(fr, pid, t)
            if f and _dist((f[1], f[2]), xy) <= NEAR_OBJ:
                pres += 1
        out.append(_item("objetivos", pres / len(mine_o) >= 0.6, "Presença nos objetivos do seu time",
                         f"Você estava perto em {pres} de {len(mine_o)} objetivos que o seu time pegou (dragão, Arauto, barão)."))

    # na base quando um objetivo caiu (vivo)
    if objs:
        base = 0
        for t, _tm, _xy in objs:
            if any(t - 70000 <= d <= t for d in deaths):
                continue
            f = _at(fr, pid, t)
            if f and _dist((f[1], f[2]), FOUNTAIN.get(team, FOUNTAIN[100])) <= BASE_R:
                base += 1
        out.append(_item("recall_obj", base == 0, "Na base durante objetivo",
                         f"Você estava na base em {base} dos {len(objs)} objetivos da partida." if base else "Nunca estava na base quando um objetivo caiu."))
    return out


def html_card(items):
    if not items:
        return ""
    ico = {True: "<b style='color:#6BBF8A'>&#10003;</b>", False: "<b style='color:#E5564E'>&#10007;</b>", None: "<b style='color:#9A8F86'>&ndash;</b>"}
    rows = "".join(
        f"<li style='margin:7px 0'>{ico[x['ok']]} <b>{e(x['titulo'])}</b><br><span class='n'>{e(x['detalhe'])}</span> "
        f"<a class='go' href='/aulas#{e(x['licao'])}' style='white-space:nowrap'>Ver a aula</a></li>" for x in items)
    return ("<div class='card'><b class='gl'>Plano da partida</b>"
            "<p class='n'>O que as aulas pedem, medido nesta partida.</p>"
            f"<ul style='list-style:none;padding:0;margin:8px 0 0'>{rows}</ul></div>")


html = html_card   # nome publico: plano.html(items)  (o modulo html acima so serve ao escape)
